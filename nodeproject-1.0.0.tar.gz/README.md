# node-project
NodeJS demo project to deploy end to end using github action CI/CD.
# install the npm
```bash
sudo apt-get install npm
```
# check npm and node version
```bash 
npm -v

node -v
```